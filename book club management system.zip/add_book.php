<?php
session_start();
$conn = new mysqli("localhost", "root", "", "book_club_system");

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $title = $_POST["title"];
    $author = $_POST["author"];
    $genre = $_POST["genre"];
    $published_year = $_POST["published_year"];
    $total_copies = $_POST["total_copies"];
    $available_copies = $_POST["total_copies"]; // Initially, all copies are available

    $sql = "INSERT INTO books (title, author, genre, published_year, total_copies, available_copies) 
            VALUES ('$title', '$author', '$genre', '$published_year', '$total_copies', '$available_copies')";

if (mysqli_query($conn, $sql)) {
    // Add notification
    
    $notif_title = "📚 New Book: " . mysqli_real_escape_string($conn, $title);
    $notif_message = "The book titled '" . mysqli_real_escape_string($conn, $title) . "' by $author has been added to the library.";
    $created_at = date('Y-m-d H:i:s');

    $insert_notification = "INSERT INTO notifications (title, message, created_at) 
                            VALUES ('$title', '$message', '$created_at')";
    mysqli_query($conn, $insert_notification);

    echo "Book added and notification sent.";
} else {
    echo "Error: " . mysqli_error($conn);
}
    if ($conn->query($sql) === TRUE) {
        $_SESSION["success"] = "✅ Book added successfully!";
        header("Location: manage_books.php");
        exit();
    } else {
        $_SESSION["error"] = "❌ Error adding book: " . $conn->error;
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>➕ Add New Book</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <style>
        body {
            background-color: #f8f9fa;
        }
        .container {
            background: white;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            max-width: 500px;
        }
    </style>
</head>
<body>

<div class="container mt-5">
    <h2 class="text-center">➕ Add New Book</h2>

    <?php if (isset($_SESSION["error"])) { ?>
        <div class="alert alert-danger"><?= $_SESSION["error"]; unset($_SESSION["error"]); ?></div>
    <?php } ?>

    <form method="POST">
        <div class="mb-3">
            <label class="form-label">📖 Book Title</label>
            <input type="text" name="title" class="form-control" required>
        </div>

        <div class="mb-3">
            <label class="form-label">✍ Author</label>
            <input type="text" name="author" class="form-control" required>
        </div>

        <div class="mb-3">
            <label class="form-label">📚 Genre</label>
            <input type="text" name="genre" class="form-control">
        </div>

        <div class="mb-3">
            <label class="form-label">📅 Published Year</label>
            <input type="number" name="published_year" class="form-control">
        </div>

        <div class="mb-3">
            <label class="form-label">📦 Total Copies</label>
            <input type="number" name="total_copies" class="form-control" required min="1">
        </div>

        <div class="text-center">
            <button type="submit" class="btn btn-success">✅ Add Book</button>
            <a href="manage_books.php" class="btn btn-secondary">⬅️ Back</a>
        </div>
    </form>
</div>

</body>
</html>
