<?php
session_start();
$conn = new mysqli("localhost", "root", "", "book_club_system");

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Fetch books data
$sql = "SELECT book_id, title, author, genre, published_year, available_copies FROM books";
$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>📚 Manage Books</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <style>
        body {
            background-color: #f8f9fa;
        }
        .container {
            background: white;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }
        .table th {
            background-color: #007BFF;
            color: white;
        }
        .btn {
            border-radius: 5px;
        }
    </style>
</head>
<body>

<div class="container mt-5 p-4">
    <h2 class="text-center">📚 Manage Books</h2>
    
    <div class="text-end mb-3">
        <a href="add_book.php" class="btn btn-success">➕ Add New Book</a>
    </div>

    <table class="table table-hover table-bordered text-center">
        <thead>
            <tr>
                <th>📖 Title</th>
                <th>✍ Author</th>
                <th>📚 Genre</th>
                <th>📅 Year</th>
                <th>📦 Available Copies</th>
                <th>⚙️ Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php while ($book = $result->fetch_assoc()) { ?>
                <tr>
                    <td><?= htmlspecialchars($book["title"]) ?></td>
                    <td><?= htmlspecialchars($book["author"]) ?></td>
                    <td><?= htmlspecialchars($book["genre"] ?? "N/A") ?></td>
                    <td><?= htmlspecialchars($book["published_year"] ?? "N/A") ?></td>
                    <td><?= isset($book["available_copies"]) ? $book["available_copies"] : 0 ?></td>
                    <td>
                        <a href="edit_book.php?id=<?= $book["book_id"] ?>" class="btn btn-warning btn-sm">✏️ Edit</a>
                        <a href="delete_book.php?id=<?= $book["book_id"] ?>" class="btn btn-danger btn-sm" onclick="return confirm('Are you sure you want to delete this book?');">🗑 Delete</a>
                    </td>
                </tr>
            <?php } ?>
        </tbody>
    </table>
    
    <div class="text-end">
        <a href="admin_dashboard.php" class="btn btn-secondary">⬅️ Back to Dashboard</a>
    </div>
</div>

</body>
</html>
