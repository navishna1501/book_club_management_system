<?php
session_start();
$conn = new mysqli("localhost", "root", "", "book_club_system");

// Redirect if not logged in
if (!isset($_SESSION["user_id"]) || $_SESSION["role"] != "user") {
    header("Location: login.php");
    exit();
}

// Fetch User Info
$user_id = $_SESSION["user_id"];
$user_query = $conn->query("SELECT * FROM users WHERE user_id = $user_id");
$user = $user_query->fetch_assoc();

// Update user information
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = $_POST['name'];
    $email = $_POST['email'];

    // Update user information in the database
    $stmt = $conn->prepare("UPDATE users SET name = ?, email = ? WHERE user_id = ?");
    $stmt->bind_param("ssi", $name, $email, $user_id);
    $stmt->execute();

    if ($stmt->affected_rows > 0) {
        echo "<p>Profile updated successfully!</p>";
    } else {
        echo "<p>No changes made.</p>";
    }
    $stmt->close();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Edit Profile | Book Club</title>
</head>
<body>
    <h2>Edit Profile</h2>
    <form method="POST">
        <label for="name">Name:</label><br>
        <input type="text" name="name" id="name" value="<?= htmlspecialchars($user['name']); ?>" required><br><br>
        
        <label for="email">Email:</label><br>
        <input type="email" name="email" id="email" value="<?= htmlspecialchars($user['email']); ?>" required><br><br>
        
        <button type="submit">Update Profile</button>
    </form>
    <a href="user_dashboard.php">Back to Dashboard</a>
</body>
</html>
