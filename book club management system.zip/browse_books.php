<?php
session_start();
$conn = new mysqli("localhost", "root", "", "book_club_system");

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Search books if a query is provided
$search = isset($_GET['search']) ? $_GET['search'] : '';
$sql = "SELECT * FROM books WHERE title LIKE '%$search%' OR author LIKE '%$search%' OR genre LIKE '%$search%'";
$books = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>📚 Browse Books</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
    <style>
        body {
            background-color: #f8f9fa;
        }
        .container {
            margin-top: 40px;
            max-width: 900px;
        }
        .search-bar {
            display: flex;
            gap: 10px;
        }
        .book-card {
            border-radius: 10px;
            overflow: hidden;
            transition: transform 0.3s ease-in-out;
        }
        .book-card:hover {
            transform: scale(1.05);
        }
        .borrow-btn {
            background-color: #007BFF;
            color: white;
            border-radius: 5px;
            padding: 8px 12px;
            text-decoration: none;
        }
        .borrow-btn:hover {
            background-color: #0056b3;
        }
    </style>
</head>
<body>

<div class="container">
    <h2 class="text-center mb-4">📚 Browse Books</h2>

    <!-- Search Bar -->
    <form method="GET" class="mb-4">
        <div class="input-group">
            <input type="text" name="search" class="form-control" placeholder="Search books by title, author, or genre..." value="<?= htmlspecialchars($search); ?>">
            <button class="btn btn-primary" type="submit">🔍 Search</button>
        </div>
    </form>

    <!-- Books Display -->
    <div class="row">
        <?php while ($book = $books->fetch_assoc()) { ?>
            <div class="col-md-6">
                <div class="card book-card shadow-sm mb-3">
                    <div class="card-body">
                        <h5 class="card-title"><?= htmlspecialchars($book['title']); ?></h5>
                        <p class="card-text"><strong>Author:</strong> <?= htmlspecialchars($book['author']); ?></p>
                        <p class="card-text"><strong>Genre:</strong> <?= htmlspecialchars($book['genre']); ?></p>
                        <p class="card-text"><strong>Available:</strong> <?= $book['available_copies']; ?> copies</p>
                        <a href="borrow_book.php?book_id=<?= $book['book_id']; ?>" class="borrow-btn">📖 Borrow</a>
                    </div>
                </div>
            </div>
        <?php } ?>
    </div>

    <!-- Back to Dashboard Button -->
    <div class="text-center mt-4">
        <a href="user_dashboard.php" class="btn btn-secondary">🏠 Back to Dashboard</a>
    </div>
</div>

</body>
</html>

<?php
$conn->close();
?>
