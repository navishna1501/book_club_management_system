<?php
session_start();
$conn = new mysqli("localhost", "root", "", "book_club_system");

if (!isset($_SESSION["user_id"]) || !isset($_GET["meeting_id"])) {
    header("Location: meetings.php");
    exit();
}

$meeting_id = $_GET["meeting_id"];
$user_id = $_SESSION["user_id"];

$conn->query("INSERT INTO meeting_attendance (user_id, meeting_id) VALUES ($user_id, $meeting_id)");
echo "<script>alert('RSVP confirmed!'); window.location='meetings.php';</script>";
?>
