<?php
session_start();
$conn = new mysqli("localhost", "root", "", "book_club_system");

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['save_edit'])) {
    $id = intval($_POST['discussion_id']);
    $title = $conn->real_escape_string($_POST['title']);
    $message = $conn->real_escape_string($_POST['message']);

    $update = "UPDATE discussions SET title='$title', message='$message' WHERE discussion_id=$id";
    if ($conn->query($update)) {
        $_SESSION['message'] = "✅ Discussion updated!";
    } else {
        $_SESSION['message'] = "❌ Update failed.";
    }
}

header("Location: admin_discussion.php");
exit();
