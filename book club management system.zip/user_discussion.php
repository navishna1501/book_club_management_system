<?php
session_start();
$conn = new mysqli("localhost", "root", "", "book_club_system");

if (!isset($_SESSION["user_id"])) {
    header("Location: login.php");
    exit();
}

$user_id = $_SESSION["user_id"];

$discussions_query = "
    SELECT discussions.discussion_id, discussions.title, discussions.message, discussions.created_at, users.name 
    FROM discussions 
    JOIN users ON discussions.user_id = users.user_id 
    ORDER BY discussions.created_at DESC";

$result = $conn->query($discussions_query);

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $title = trim($_POST['title']);
    $message = trim($_POST['message']);

    if (!empty($title) && !empty($message)) {
        $insert_query = "INSERT INTO discussions (user_id, title, message, created_at) VALUES (?, ?, ?, NOW())";
        $stmt = $conn->prepare($insert_query);
        $stmt->bind_param("iss", $user_id, $title, $message);
        $stmt->execute();

        if ($stmt->affected_rows > 0) {
            header("Location: user_discussion.php");
            exit();
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>User Discussion Forum</title>
    <style>
        body {
            font-family: 'Arial', sans-serif;
            background-color: #f4f7fc;
            margin: 0;
            padding: 0;
        }

        h2 {
            text-align: center;
            color: #2a3b8f;
            margin-top: 20px;
        }

        form {
            max-width: 600px;
            margin: 20px auto;
            background-color: #ffffff;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
        }

        form input, form textarea {
            width: 100%;
            padding: 10px;
            margin-bottom: 15px;
            border: 1px solid #ccc;
            border-radius: 4px;
            box-sizing: border-box;
        }

        form button {
            background-color: #5cb85c;
            color: white;
            border: none;
            padding: 10px 20px;
            font-size: 16px;
            border-radius: 4px;
            cursor: pointer;
            transition: background-color 0.3s;
        }

        form button:hover {
            background-color: #4cae4c;
        }

        .discussion {
            background-color: #fff;
            margin: 10px auto;
            padding: 15px;
            border-radius: 8px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
            width: 80%;
        }

        .discussion h3 {
            color: #333;
            margin-bottom: 10px;
        }

        .discussion p {
            color: #555;
            line-height: 1.6;
        }

        .discussion small {
            color: #888;
        }

        .discussion-actions {
            margin-top: 10px;
        }

        .discussion-actions a {
            text-decoration: none;
            color: #5cb85c;
            margin-right: 15px;
            font-weight: bold;
            transition: color 0.3s;
        }

        .discussion-actions a:hover {
            color: #4cae4c;
        }

        .back-link {
            display: block;
            text-align: center;
            margin-top: 30px;
        }

        .back-button {
            background-color: #2a3b8f;
            color: white;
            border: none;
            padding: 10px 20px;
            font-size: 16px;
            font-weight: bold;
            border-radius: 5px;
            cursor: pointer;
            text-align: center;
            display: inline-block;
            transition: background-color 0.3s, transform 0.2s;
            text-decoration: none;
        }

        .back-button:hover {
            background-color: #4cae4c;
            transform: translateX(-5px); /* Slightly moves the button to the left on hover */
        }

        .back-button:active {
            background-color: #398839; /* Darker shade when clicked */
        }
    </style>
</head>
<body>
    <h2>💬 User Discussion Forum</h2>
    <form method="POST">
        <input type="text" name="title" placeholder="Discussion Title" required>
        <textarea name="message" placeholder="Write your message..." required></textarea>
        <button type="submit">Post</button>
    </form>

    <div class="discussion-list">
        <?php while ($discussion = $result->fetch_assoc()) { ?>
            <div class="discussion">
                <h3><?= htmlspecialchars($discussion['title']) ?></h3>
                <p><?= htmlspecialchars($discussion['message']) ?></p>
                <small>By <?= htmlspecialchars($discussion['name']) ?> on <?= $discussion['created_at'] ?></small>
                <div class="discussion-actions">
                    <a href="edit_discussion.php?discussion_id=<?= $discussion['discussion_id'] ?>">Edit</a>
                    <a href="delete_discussion.php?discussion_id=<?= $discussion['discussion_id'] ?>" onclick="return confirm('Are you sure you want to delete this discussion?');">Delete</a>
                </div>
            </div>
        <?php } ?>
    </div>

    <a href="user_dashboard.php" class="back-link">
         </a>
         <div class="text-center mt-4">
            <a href="user_dashboard.php" class="btn btn-secondary"><button>⬅️ Back to Dashboard</button></a>
   
    </div>
</body>
</html>
