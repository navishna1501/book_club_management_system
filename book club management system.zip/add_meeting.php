<?php
session_start();
require 'db_connect.php';

if (!isset($_SESSION["user_id"]) || $_SESSION["role"] != "admin") {
    header("Location: login.php");
    exit();
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $title = trim($_POST["title"]);
    $description = trim($_POST["description"]);
    $meeting_date = $_POST["meeting_date"];
    $organizer_id = $_SESSION["user_id"];

    if (!empty($title) && !empty($meeting_date)) {
        $stmt = $conn->prepare("INSERT INTO meetings (title, description, meeting_date, organizer_id) VALUES (?, ?, ?, ?)");
        $stmt->bind_param("sssi", $title, $description, $meeting_date, $organizer_id);

        if ($stmt->execute()) {
            header("Location: manage_meetings.php");
            exit();
        } else {
            $error = "Error scheduling meeting: " . $conn->error;
        }
    } else {
        $error = "Title and date are required!";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Schedule Meeting</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <h2>Schedule a New Meeting</h2>
    <?php if (isset($error)) echo "<p style='color:red;'>$error</p>"; ?>
    
    <form method="POST">
        <input type="text" name="title" placeholder="Meeting Title" required><br>
        <textarea name="description" placeholder="Meeting Description"></textarea><br>
        <input type="datetime-local" name="meeting_date" required><br>
        <button type="submit">Schedule Meeting</button>
    </form>

    <a href="manage_meetings.php">Back</a>
</body>
</html>
