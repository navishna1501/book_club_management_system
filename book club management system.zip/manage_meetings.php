<?php
session_start();
$conn = new mysqli("localhost", "root", "", "book_club_system");

// Check if admin is logged in
if (!isset($_SESSION["user_id"]) || $_SESSION["role"] != "admin") {
    header("Location: login.php");
    exit();
}

// Initialize messages
$message = "";

// Handle Meeting Scheduling
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $title = trim($_POST["title"]);
    $description = trim($_POST["description"]);
    $meeting_date = $_POST["meeting_date"];

    // Basic Validation
    if (empty($title) || empty($description) || empty($meeting_date)) {
        $message = "<div class='alert alert-danger'>⚠️ All fields are required.</div>";
    } else {
        $sql = "INSERT INTO meetings (title, description, meeting_date) 
                VALUES ('$title', '$description', '$meeting_date')";

        if ($conn->query($sql) === TRUE) {
            $message = "<div class='alert alert-success'>✅ Meeting scheduled successfully!</div>";
        } else {
            $message = "<div class='alert alert-danger'>❌ Error scheduling meeting: " . $conn->error . "</div>";
        }
    }
}

// Handle Meeting Deletion
if (isset($_GET['delete_id'])) {
    $delete_id = $_GET['delete_id'];

    // Prepare and execute deletion
    $stmt = $conn->prepare("DELETE FROM meetings WHERE meeting_id = ?");
    $stmt->bind_param("i", $delete_id);

    if ($stmt->execute()) {
        $message = "<div class='alert alert-success'>✅ Meeting deleted successfully!</div>";
    } else {
        $message = "<div class='alert alert-danger'>❌ Error deleting meeting: " . $conn->error . "</div>";
    }

    $stmt->close();
}

// Fetch upcoming meetings
$meetings = $conn->query("SELECT * FROM meetings ORDER BY meeting_date ASC");
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Meetings</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
    <style>
        body {
            background-color: #f8f9fa;
            font-family: Arial, sans-serif;
        }
        .container {
            margin-top: 30px;
        }
        .card {
            transition: transform 0.2s;
        }
        .card:hover {
            transform: scale(1.05);
        }
        .btn-primary {
            background-color: #007BFF;
            border: none;
        }
        .btn-primary:hover {
            background-color: #0056b3;
        }
    </style>
</head>
<body>
    <div class="container">
        <h2 class="text-center mb-4">📅 Manage Meetings</h2>

        <!-- Display Messages -->
        <?= $message ?>

        <!-- Schedule Meeting Form -->
        <div class="card p-3 shadow-sm">
            <h4 class="text-center">📌 Schedule a Meeting</h4>
            <form method="POST">
                <div class="mb-3">
                    <input type="text" name="title" class="form-control" placeholder="Meeting Title" required>
                </div>
                <div class="mb-3">
                    <textarea name="description" class="form-control" placeholder="Meeting Description" required></textarea>
                </div>
                <div class="mb-3">
                    <input type="datetime-local" name="meeting_date" class="form-control" required>
                </div>
                <button type="submit" class="btn btn-primary w-100">📅 Schedule Meeting</button>
            </form>
        </div>

        <!-- Upcoming Meetings List -->
        <h3 class="mt-4">📌 Upcoming Meetings</h3>
        <div class="row">
            <?php while ($meeting = $meetings->fetch_assoc()) { ?>
                <div class="col-md-4">
                    <div class="card p-3 shadow-sm mt-3">
                        <h5><?= htmlspecialchars($meeting['title']) ?></h5>
                        <p><?= htmlspecialchars($meeting['description']) ?></p>
                        <p><strong>📅 Date:</strong> <?= $meeting['meeting_date'] ?></p>
                        
                        <!-- Edit Button -->
                        <a href="edit_meeting.php?id=<?= $meeting['meeting_id'] ?>" class="btn btn-sm btn-warning">✏️ Edit</a>
                        
                        <!-- Delete Button -->
                        <a href="?delete_id=<?= $meeting['meeting_id'] ?>" class="btn btn-sm btn-danger" onclick="return confirm('Are you sure you want to delete this meeting?')">🗑️ Delete</a>
                    </div>
                </div>
            <?php } ?>
        </div>

        <a href="admin_dashboard.php" class="btn btn-secondary mt-4">🏠 Back to Dashboard</a>
    </div>
</body>
</html>
