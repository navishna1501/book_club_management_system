<?php
session_start();
$conn = new mysqli("localhost", "root", "", "book_club_system");

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if (!isset($_SESSION["user_id"]) || $_SESSION["role"] != "admin") {
    header("Location: login.php");
    exit();
}

$order_fields = ['username', 'name', 'email'];
$ordered = false;
foreach ($order_fields as $field) {
    $test_query = $conn->query("SELECT `$field` FROM users LIMIT 1");
    if ($test_query) {
        $users_query = $conn->query("SELECT * FROM users ORDER BY `$field`");
        $ordered = true;
        break;
    }
}
if (!$ordered) {
    $users_query = $conn->query("SELECT * FROM users");
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>User Activity & Reports</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background: #f4f4f4;
            padding: 20px;
        }
        .container {
            background: #fff;
            border-radius: 8px;
            padding: 20px;
            max-width: 1000px;
            margin: auto;
            box-shadow: 0 0 10px rgba(0,0,0,0.1);
        }
        h2 {
            text-align: center;
            color: #333;
        }
        .search-box {
            text-align: center;
            margin-bottom: 20px;
        }
        .search-box input {
            padding: 10px;
            width: 80%;
            max-width: 400px;
            border-radius: 5px;
            border: 1px solid #ccc;
        }
        .user-section {
            background: #f9f9f9;
            padding: 15px;
            margin-bottom: 20px;
            border-radius: 5px;
        }
        .collapsible {
            background-color: #007bff;
            color: white;
            cursor: pointer;
            padding: 10px;
            border: none;
            width: 100%;
            text-align: left;
            border-radius: 5px;
            margin-top: 10px;
        }
        .collapsible:hover {
            background-color: #0056b3;
        }
        .content {
            display: none;
            background: #eee;
            padding: 10px;
            border-radius: 5px;
        }
        .back-button {
            background: #007bff;
            color: white;
            padding: 10px 20px;
            text-decoration: none;
            border-radius: 5px;
            display: inline-block;
            margin-bottom: 20px;
        }
        .back-button:hover {
            background: #0056b3;
        }
    </style>
</head>
<body>

<div class="container">
    <h2>📊 User Activity & Reports</h2>
    <a href="admin_dashboard.php" class="back-button">⬅️ Back to Dashboard</a>

    <div class="search-box">
        🔍 <input type="text" id="searchInput" placeholder="Search user by name, email, or username...">
    </div>

<?php while ($user = mysqli_fetch_assoc($users_query)) :
    $user_id = isset($user['id']) ? intval($user['id']) : 0;
    $username = htmlspecialchars($user['username'] ?? 'unknown');
    $name = htmlspecialchars($user['name'] ?? '');
    $email = htmlspecialchars($user['email'] ?? '');
    $display_name = $username ?: $name ?: $email ?: 'User';
?>
    <div class="user-section" data-search="<?php echo strtolower($username . ' ' . $name . ' ' . $email); ?>">
        <h3>👤 <?php echo $display_name; ?></h3>

        <!-- Borrowed Books -->
        <button class="collapsible">📚 Borrowed Books</button>
        <div class="content">
            <?php
            $books_query = $conn->query("SELECT * FROM borrowed_books WHERE user_id = $user_id");
            if ($books_query && $books_query->num_rows > 0) {
                echo "<ul>";
                while ($book = $books_query->fetch_assoc()) {
                    $returned = $book['returned_date'] ? "Returned on: " . htmlspecialchars($book['returned_date']) : "<em>Not yet returned</em>";
                    echo "<li><strong>" . htmlspecialchars($book['book_title']) . "</strong><br>Borrowed: " . htmlspecialchars($book['borrowed_date']) . "<br>$returned</li>";
                }
                echo "</ul>";
            } else {
                echo "<em>No borrowed books.</em>";
            }
            ?>
        </div>

        <!-- Meeting Attendance -->
        <button class="collapsible">📅 Meeting Attendance</button>
        <div class="content">
            <?php
            $meetings_query = $conn->query("SELECT * FROM meeting_attendance WHERE user_id = $user_id");
            if ($meetings_query && $meetings_query->num_rows > 0) {
                echo "<ul>";
                while ($meeting = $meetings_query->fetch_assoc()) {
                    echo "<li>Meeting ID: <strong>" . $meeting['meeting_id'] . "</strong> - " . $meeting['attended_date'] . "</li>";
                }
                echo "</ul>";
            } else {
                echo "<em>No attendance records.</em>";
            }
            ?>
        </div>

        <!-- Missed Meetings -->
        <button class="collapsible">❌ Missed Meetings</button>
        <div class="content">
            <?php
            $attended_ids = [];
            $attended_result = $conn->query("SELECT meeting_id FROM meeting_attendance WHERE user_id = $user_id");
            while ($row = $attended_result->fetch_assoc()) {
                $attended_ids[] = $row['meeting_id'];
            }
            $exclude = count($attended_ids) > 0 ? "WHERE id NOT IN (" . implode(",", $attended_ids) . ")" : "";
            $missed_query = $conn->query("SELECT * FROM meetings $exclude");
            if ($missed_query && $missed_query->num_rows > 0) {
                echo "<ul>";
                while ($meeting = $missed_query->fetch_assoc()) {
                    echo "<li><strong>" . htmlspecialchars($meeting['title']) . "</strong> on " . htmlspecialchars($meeting['meeting_date']) . "</li>";
                }
                echo "</ul>";
            } else {
                echo "<em>No missed meetings.</em>";
            }
            ?>
        </div>

        <!-- Discussions Started -->
        <button class="collapsible">💬 Discussions Started</button>
        <div class="content">
            <?php
            $discussions_query = $conn->query("SELECT * FROM discussions WHERE user_id = $user_id");
            if ($discussions_query && $discussions_query->num_rows > 0) {
                echo "<ul>";
                while ($discussion = $discussions_query->fetch_assoc()) {
                    echo "<li><strong>" . htmlspecialchars($discussion['title']) . "</strong> - " . htmlspecialchars($discussion['created_at']) . "</li>";
                }
                echo "</ul>";
            } else {
                echo "<em>No discussions started.</em>";
            }
            ?>
        </div>
    </div>
<?php endwhile; ?>
</div>

<script>
document.addEventListener("DOMContentLoaded", function () {
    const collapsibles = document.querySelectorAll(".collapsible");
    collapsibles.forEach(btn => {
        btn.addEventListener("click", function () {
            this.classList.toggle("active");
            const content = this.nextElementSibling;
            content.style.display = content.style.display === "block" ? "none" : "block";
        });
    });

    const searchInput = document.getElementById("searchInput");
    const userSections = document.querySelectorAll(".user-section");

    searchInput.addEventListener("input", function () {
        const query = this.value.toLowerCase();
        userSections.forEach(section => {
            const text = section.getAttribute("data-search");
            section.style.display = text.includes(query) ? "block" : "none";
        });
    });
});
</script>

</body>
</html>
