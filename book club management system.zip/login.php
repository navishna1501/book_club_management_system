<?php
session_start();
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

$conn = new mysqli("localhost", "root", "", "book_club_system");

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = $_POST["email"];
    $password = $_POST["password"];

    // Prevent SQL Injection
    $stmt = $conn->prepare("SELECT user_id, name, password, role FROM users WHERE email = ?");
    if (!$stmt) {
        die("SQL Error: " . $conn->error); // Debugging error
    }
    
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $stmt->store_result();
    
    if ($stmt->num_rows > 0) {
        $stmt->bind_result($user_id, $name, $hashed_password, $role);
        $stmt->fetch();
        // Debugging output (uncomment if needed)
        // echo "User: $user_id, Name: $name, Role: $role"; exit();  
        if (password_verify($password, $hashed_password)) {
            $_SESSION["user_id"] = $user_id;
            $_SESSION["name"] = $name;
            $_SESSION["role"] = $role;

            // Redirect based on role
            if ($role == "admin") {
                header("Location: admin_dashboard.php");
            } else {
                header("Location: user_dashboard.php");
            }
            exit();
        } else {
            $error = "❌ Incorrect password!";
        }
    } else {
        $error = "❌ No account found with this email!";
    }
    $stmt->close();
}
$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Login | Book Club</title>
    <link rel="stylesheet" href="styles.css">
    <style>
        body {
            font-family: Arial, sans-serif;
            background: url('images/login2.jpg') no-repeat center center fixed;
            background-size: cover; /* Makes the background cover the entire page */
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
        }
        .login-container {
            background: white;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.2);
            text-align: center;
            width: 300px;
        }
        h2 {
            color: #333;
        }
        input {
            width: 80%;        /* smaller width */
            padding: 8px;      /* reduce padding */
            margin: 8px 0;
            font-size: 14px;   /* smaller text */
            border: 1px solid #ccc;
            border-radius: 4px;
        }

        button {
            background: #007BFF;
            color: white;
            border: none;
            padding: 8px;       /* smaller padding */
            border-radius: 4px;
            cursor: pointer;
            width: 60%;         /* same as input width */
            font-size: 14px;
        }


        button:hover {
            background: #0056b3;
        }
        .error {
            color: red;
        }
    </style>
</head>
<body>

<div class="login-container">
    <h2>🔑 Login to Book Club</h2>
    
    <?php if (isset($error)) { echo "<p class='error'>$error</p>"; } ?>

    <form method="POST">
        <input type="email" name="email" placeholder="📧 Email" required>
        <input type="password" name="password" placeholder="🔒 Password" required>
        <button type="submit">🚀 Login</button>
    </form>
    <p>Don't have an account? <a href="register.php">Register here</a></p>
</div>

<script>
    const error = document.querySelector('.error');
    if (error) {
        setTimeout(() => {
            error.style.display = 'none';
        }, 5000); // Hide error after 5 seconds
    }
</script>

</body>
</html>