<?php
session_start();
$conn = new mysqli("localhost", "root", "", "book_club_system");

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['send_reply'])) {
    $discussion_id = intval($_POST['discussion_id']);
    $reply = $conn->real_escape_string($_POST['reply']);
    $admin_id = $_SESSION['user_id']; // assuming logged-in admin

    $insert = "INSERT INTO admin_replies (discussion_id, admin_id, reply) VALUES ($discussion_id, $admin_id, '$reply')";
    if ($conn->query($insert)) {
        $_SESSION['message'] = "✅ Reply sent!";
    } else {
        $_SESSION['message'] = "❌ Failed to send reply.";
    }
    
}

header("Location: admin_discussion.php");
exit();
