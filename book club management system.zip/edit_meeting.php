<?php
session_start();
$conn = new mysqli("localhost", "root", "", "book_club_system");

// Check if admin is logged in
if (!isset($_SESSION["user_id"]) || $_SESSION["role"] != "admin") {
    header("Location: login.php");
    exit();
}

// Fetch meeting data
if (isset($_GET['id'])) {
    $meeting_id = $_GET['id'];
    $result = $conn->query("SELECT * FROM meetings WHERE meeting_id = $meeting_id");

    if ($result->num_rows > 0) {
        $meeting = $result->fetch_assoc();
    } else {
        header("Location: manage_meetings.php");
        exit();
    }
} else {
    header("Location: manage_meetings.php");
    exit();
}

// Update meeting details
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $title = trim($_POST["title"]);
    $description = trim($_POST["description"]);
    $meeting_date = $_POST["meeting_date"];

    // Basic Validation
    if (empty($title) || empty($description) || empty($meeting_date)) {
        $message = "<div class='alert alert-danger'>⚠️ All fields are required.</div>";
    } else {
        $stmt = $conn->prepare("UPDATE meetings SET title = ?, description = ?, meeting_date = ? WHERE meeting_id = ?");
        $stmt->bind_param("sssi", $title, $description, $meeting_date, $meeting_id);

        if ($stmt->execute()) {
            $message = "<div class='alert alert-success'>✅ Meeting updated successfully!</div>";
        } else {
            $message = "<div class='alert alert-danger'>❌ Error updating meeting: " . $conn->error . "</div>";
        }

        $stmt->close();
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Meeting</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
</head>
<body>
    <div class="container">
        <h2 class="text-center mb-4">📅 Edit Meeting</h2>

        <!-- Display Messages -->

        <!-- Edit Meeting Form -->
        <div class="card p-3 shadow-sm">
            <h4 class="text-center">✏️ Edit Meeting</h4>
            <form method="POST">
                <div class="mb-3">
                    <input type="text" name="title" class="form-control" value="<?= htmlspecialchars($meeting['title']) ?>" required>
                </div>
                <div class="mb-3">
                    <textarea name="description" class="form-control" required><?= htmlspecialchars($meeting['description']) ?></textarea>
                </div>
                <div class="mb-3">
                    <input type="datetime-local" name="meeting_date" class="form-control" value="<?= date('Y-m-d\TH:i', strtotime($meeting['meeting_date'])) ?>" required>
                </div>
                <button type="submit" class="btn btn-primary w-100">📅 Update Meeting</button>
            </form>
        </div>

        <a href="manage_meetings.php" class="btn btn-secondary mt-4">🏠 Back to Manage Meetings</a>
    </div>
</body>
</html>
