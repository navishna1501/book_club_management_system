<?php
$conn = new mysqli("localhost", "root", "", "book_club_system");
if ($conn->connect_error) {
    die("Database Connection Failed: " . $conn->connect_error);
}
?>
