<?php
session_start();
include 'db_connect.php';

// Optional: redirect to login if not logged in
if (!isset($_SESSION['user_id']) && !isset($_SESSION['admin_logged_in'])) {
    header("Location: login.php");
    exit();
}

// Fetch notifications
$result = mysqli_query($conn, "SELECT * FROM notifications ORDER BY created_at DESC");
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">

    <style>
        body {
            font-family: 'Segoe UI', sans-serif;
            background-color: #f4f4f4;
            padding: 20px;
        }

        .container {
            max-width: 900px;
            margin: 0 auto;
            background: white;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 3px 10px rgba(0,0,0,0.1);
        }

        h2 {
            text-align: center;
            color: #007bff;
        }

        .notification {
            padding: 15px;
            margin-bottom: 15px;
            border-left: 5px solid #007bff;
            background-color: #f9f9f9;
            border-radius: 5px;
        }

        .notification h4 {
            margin: 0 0 5px;
            color: #333;
        }

        .notification p {
            margin: 0;
            color: #555;
        }

        .timestamp {
            font-size: 0.85em;
            color: #999;
            margin-top: 5px;
        }

        .back-btn {
            display: inline-block;
            margin-top: 20px;
            background-color: #007bff;
            color: white;
            padding: 10px 16px;
            text-decoration: none;
            border-radius: 5px;
        }

        .back-btn:hover {
            background-color: #0056b3;
        }
    </style>
</head>
<body>

<div class="container">
    <h2>🔔 Notifications</h2>

    <?php if (mysqli_num_rows($result) > 0): ?>
        <?php while ($row = mysqli_fetch_assoc($result)): ?>
            <div class="notification">
                <h4><?php echo htmlspecialchars($row['title']); ?></h4>
                <p><?php echo htmlspecialchars($row['message']); ?></p>
                <div class="timestamp">📅 <?php echo date("F d, Y h:i A", strtotime($row['created_at'])); ?></div>
            </div>
        <?php endwhile; ?>
    <?php else: ?>
        <p>No notifications available at this moment.</p>
    <?php endif; ?>

    <a class="back-btn" href="<?php echo isset($_SESSION['admin_logged_in']) ? 'admin_dashboard.php' : 'user_dashboard.php'; ?>">⬅ Back to Dashboard</a>
</div>

</body>
</html>
