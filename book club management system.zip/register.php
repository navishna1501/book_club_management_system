<?php
session_start();
$conn = new mysqli("localhost", "root", "", "book_club_system");

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = $_POST["name"];
    $email = $_POST["email"];
    $password = password_hash($_POST["password"], PASSWORD_DEFAULT);
    $role = $_POST["role"]; // 'admin' or 'member'

    // Check if email already exists
    $check_email = $conn->query("SELECT * FROM users WHERE email='$email'");
    if ($check_email->num_rows > 0) {
        $error = "Email already exists!";
    } else {
        $sql = "INSERT INTO users (name, email, password, role) VALUES ('$name', '$email', '$password', '$role')";
        if ($conn->query($sql) === TRUE) {
            header("Location: login.php?registered=true");
            exit();
        } else {
            $error = "Registration failed!";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Register</title>
    <link rel="stylesheet" href="styles.css">
    <style>
    body {
        background: url('https://www.cumberland.nsw.gov.au/sites/default/files/styles/16_9/public/2022-06/book-club..JPG?h=1a2b2c6d&itok=U7H2R6Xj') no-repeat center center fixed;
        background-size: cover;
        font-family: Arial, sans-serif;
        margin: 0;
        padding: 0;
    }

    .register-container {
        background: rgba(255, 255, 255, 0.9);
        padding: 20px;
        border-radius: 10px;
        width: 300px;
        margin: 100px auto;
        box-shadow: 0 5px 15px rgba(0, 0, 0, 0.3);
        text-align: center;
    }
        h2 {
            color: #333;
        }
        input, select {
            width: 90%;
            padding: 10px;
            margin: 10px 0;
            border: 1px solid #ccc;
            border-radius: 5px;
        }
        .btn {
            display: block;
            width: 100%;
            padding: 10px;
            margin: 10px 0;
            text-decoration: none;
            color: white;
            background-color: #28a745;
            border: none;
            border-radius: 5px;
            transition: background 0.3s;
            cursor: pointer;
        }
        .btn:hover {
            background-color: #218838;
        }
        .error {
            color: red;
        }
    </style>
</head>
<body>
    <div class="container">
        <?php if (isset($error)) echo "<p class='error'>$error</p>"; ?>
        <form method="POST">
        <body>
    <div class="register-container">
        <h2>📝 Register to Book Club</h2>
        <form method="POST" action="register.php">
            <input type="text" name="name" placeholder="👤 Full Name" required><br>
            <input type="email" name="email" placeholder="📧 Email" required><br>
            <input type="password" name="password" placeholder="🔒 Password" required><br>
            <select name="role" required>
                <option value="member">Member</option>
                <option value="admin">Admin</option>
            </select><br>
            <button type="submit" class="btn">Register</button>
        </form>
        <a href="login.php">Already have an account? Login</a>
    </div>
</body>
</html>
