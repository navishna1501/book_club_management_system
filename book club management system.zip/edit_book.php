<?php
session_start();
$conn = new mysqli("localhost", "root", "", "book_club_system");

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if (!isset($_GET["id"])) {
    $_SESSION["error"] = "❌ No book selected!";
    header("Location: manage_books.php");
    exit();
}

$book_id = $_GET["id"];
$sql = "SELECT * FROM books WHERE book_id = $book_id";
$result = $conn->query($sql);

if ($result->num_rows == 0) {
    $_SESSION["error"] = "❌ Book not found!";
    header("Location: manage_books.php");
    exit();
}

$book = $result->fetch_assoc();

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $title = $_POST["title"];
    $author = $_POST["author"];
    $genre = $_POST["genre"];
    $published_year = $_POST["published_year"];
    $total_copies = $_POST["total_copies"];
    $available_copies = $_POST["available_copies"];

    $update_sql = "UPDATE books SET 
        title = '$title', 
        author = '$author', 
        genre = '$genre', 
        published_year = '$published_year', 
        total_copies = '$total_copies',
        available_copies = '$available_copies'
        WHERE book_id = $book_id";

    if ($conn->query($update_sql) === TRUE) {
        $_SESSION["success"] = "✅ Book updated successfully!";
        header("Location: manage_books.php");
        exit();
    } else {
        $_SESSION["error"] = "❌ Error updating book: " . $conn->error;
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>✏️ Edit Book</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <style>
        body {
            background-color: #f8f9fa;
        }
        .container {
            background: white;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            max-width: 500px;
        }
    </style>
</head>
<body>

<div class="container mt-5">
    <h2 class="text-center">✏️ Edit Book</h2>

    <?php if (isset($_SESSION["error"])) { ?>
        <div class="alert alert-danger"><?= $_SESSION["error"]; unset($_SESSION["error"]); ?></div>
    <?php } ?>

    <form method="POST">
        <div class="mb-3">
            <label class="form-label">📖 Book Title</label>
            <input type="text" name="title" class="form-control" value="<?= $book['title'] ?>" required>
        </div>

        <div class="mb-3">
            <label class="form-label">✍ Author</label>
            <input type="text" name="author" class="form-control" value="<?= $book['author'] ?>" required>
        </div>

        <div class="mb-3">
            <label class="form-label">📚 Genre</label>
            <input type="text" name="genre" class="form-control" value="<?= $book['genre'] ?>">
        </div>

        <div class="mb-3">
            <label class="form-label">📅 Published Year</label>
            <input type="number" name="published_year" class="form-control" value="<?= $book['published_year'] ?>">
        </div>

        <div class="mb-3">
            <label class="form-label">📦 Total Copies</label>
            <input type="number" name="total_copies" class="form-control" value="<?= $book['total_copies'] ?>" required min="1">
        </div>

        <div class="mb-3">
            <label class="form-label">✅ Available Copies</label>
            <input type="number" name="available_copies" class="form-control" value="<?= $book['available_copies'] ?>" required min="0">
        </div>

        <div class="text-center">
            <button type="submit" class="btn btn-primary">💾 Save Changes</button>
            <a href="manage_books.php" class="btn btn-secondary">⬅️ Back</a>
        </div>
    </form>
</div>

</body>
</html>
