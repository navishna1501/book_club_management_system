<?php
session_start();
$conn = new mysqli("localhost", "root", "", "book_club_system");

// Check if the user is logged in and is an admin
if (!isset($_SESSION["user_id"]) || $_SESSION["role"] !== "admin") {
    header("Location: login.php");
    exit();
}

// Fetch all discussions using a prepared statement
$discussions_query = "
    SELECT discussions.discussion_id, discussions.title, discussions.message, discussions.created_at, users.name 
    FROM discussions 
    JOIN users ON discussions.user_id = users.user_id 
    ORDER BY discussions.created_at DESC";
$result = $conn->query($discussions_query);

// Handle delete action
if (isset($_GET['delete'])) {
    $discussion_id = intval($_GET['delete']); // Ensure it's an integer

    // Start a transaction to delete discussion and associated replies
    $conn->begin_transaction();

    try {
        // Delete replies related to the discussion
        $delete_replies = "DELETE FROM admin_replies WHERE discussion_id = ?";
        $stmt = $conn->prepare($delete_replies);
        $stmt->bind_param("i", $discussion_id);
        $stmt->execute();

        // Delete the discussion
        $delete_discussion = "DELETE FROM discussions WHERE discussion_id = ?";
        $stmt = $conn->prepare($delete_discussion);
        $stmt->bind_param("i", $discussion_id);
        $stmt->execute();

        // Commit the transaction
        $conn->commit();

        $_SESSION['message'] = "✅ Discussion and associated replies deleted successfully!";
    } catch (Exception $e) {
        // Rollback the transaction if an error occurs
        $conn->rollback();
        $_SESSION['message'] = "❌ Error deleting discussion and replies!";
    }

    header("Location: admin_discussion.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Discussion Management</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
</head>
<body class="bg-light">
<div class="container mt-4">
    <h2 class="text-center">🛠️ Admin Discussion Management</h2>

    <!-- Display success or error message -->
    <?php if (isset($_SESSION['message'])): ?>
        <div class="alert alert-info text-center">
            <?= $_SESSION['message']; ?>
        </div>
        <?php unset($_SESSION['message']); // Clear message after display ?>
    <?php endif; ?>

    <table class="table table-striped table-bordered mt-4">
        <thead class="table-dark">
            <tr>
                <th>Title</th>
                <th>Message</th>
                <th>Posted By</th>
                <th>Date</th>
                <th>Action</th>
            </tr>
        </thead>
        <tbody>
            <?php while ($discussion = $result->fetch_assoc()) { ?>
                <tr>
                    <td><?= htmlspecialchars($discussion['title']) ?></td>
                    <td><?= htmlspecialchars($discussion['message']) ?></td>
                    <td><?= htmlspecialchars($discussion['name']) ?></td>
                    <td><?= $discussion['created_at'] ?></td>
                    <td>
                        <!-- Edit button opens modal with pre-filled data -->
                        <a href="#" class="btn btn-warning btn-sm"
                           onclick="setEditData(<?= $discussion['discussion_id'] ?>, <?= json_encode($discussion['title']) ?>, <?= json_encode($discussion['message']) ?>)"
                           data-bs-toggle="modal" data-bs-target="#editModal">✏️ Edit</a>

                        <!-- Reply button opens modal for replying -->
                        <a href="#" class="btn btn-info btn-sm"
                           onclick="setReplyData(<?= $discussion['discussion_id'] ?>)"
                           data-bs-toggle="modal" data-bs-target="#replyModal">💬 Reply</a>

                        <!-- Delete button -->
                        <a href="admin_discussion.php?delete=<?= $discussion['discussion_id'] ?>" 
                           class="btn btn-danger btn-sm"
                           onclick="return confirm('Are you sure you want to delete this discussion and its replies?')">❌ Delete</a>
                    </td>
                </tr>
                <tr>
                    <td colspan="5">
                        <?php
                        // Display all replies to the discussion
                        $did = $discussion['discussion_id'];
                        $replies = $conn->query("SELECT r.reply, r.replied_at, u.name FROM admin_replies r JOIN users u ON r.admin_id = u.user_id WHERE r.discussion_id = $did ORDER BY r.replied_at");
                        while ($reply = $replies->fetch_assoc()) {
                            echo "<div class='p-2 bg-light border mt-2'><strong>Admin Reply by {$reply['name']}:</strong><br>" . htmlspecialchars($reply['reply']) . "<br><small><i>{$reply['replied_at']}</i></small></div>";
                        }
                        ?>
                    </td>
                </tr>
            <?php } ?>
        </tbody>
    </table>

    <div class="text-center mt-3">
        <a href="admin_dashboard.php" class="btn btn-secondary">⬅ Back to Dashboard</a>
    </div>
</div>

<!-- Edit Modal -->
<div class="modal fade" id="editModal" tabindex="-1" aria-labelledby="editModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <form method="POST" action="admin_edit_discussion.php">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title">✏️ Edit Discussion</h5>
          <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
        </div>
        <div class="modal-body">
          <input type="hidden" name="discussion_id" id="edit_id">
          <div class="mb-3">
            <label>Title</label>
            <input type="text" name="title" id="edit_title" class="form-control" required>
          </div>
          <div class="mb-3">
            <label>Message</label>
            <textarea name="message" id="edit_message" class="form-control" required></textarea>
          </div>
        </div>
        <div class="modal-footer">
          <button type="submit" name="save_edit" class="btn btn-primary">💾 Save Changes</button>
          <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
        </div>
      </div>
    </form>
  </div>
</div>

<!-- Reply Modal -->
<div class="modal fade" id="replyModal" tabindex="-1" aria-labelledby="replyModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <form method="POST" action="admin_reply_discussion.php">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title">💬 Admin Reply</h5>
          <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
        </div>
        <div class="modal-body">
          <input type="hidden" name="discussion_id" id="reply_id">
          <div class="mb-3">
            <label>Reply Message</label>
            <textarea name="reply" class="form-control" required></textarea>
          </div>
        </div>
        <div class="modal-footer">
          <button type="submit" name="send_reply" class="btn btn-success">📤 Send Reply</button>
          <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
        </div>
      </div>
    </form>
  </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script>
function setEditData(id, title, message) {
    document.getElementById('edit_id').value = id;
    document.getElementById('edit_title').value = title;
    document.getElementById('edit_message').value = message;
}

function setReplyData(id) {
    document.getElementById('reply_id').value = id;
}
</script>
</body>
</html>
