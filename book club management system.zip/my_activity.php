<?php
session_start();
$conn = new mysqli("localhost", "root", "", "book_club_system");

// Check for database connection errors
if ($conn->connect_error) {
    die("Database Connection Failed: " . $conn->connect_error);
}

// Check if user is logged in
if (!isset($_SESSION["user_id"])) {
    header("Location: login.php");
    exit();
}

$user_id = $_SESSION["user_id"];

// Fetch user's borrowed books
$borrowed_books_query = "
    SELECT books.title, books.author, borrowed_books.borrow_date, borrowed_books.return_date
    FROM borrowed_books
    JOIN books ON borrowed_books.book_id = books.book_id
    WHERE borrowed_books.user_id = ?";
$stmt = $conn->prepare($borrowed_books_query);
$stmt->bind_param("i", $user_id);
$stmt->execute();
$borrowed_books_result = $stmt->get_result();

// Fetch user's meeting attendance
$meeting_attendance_query = "
    SELECT meetings.title, meetings.meeting_date
    FROM meeting_attendance
    JOIN meetings ON meeting_attendance.meeting_id = meetings.meeting_id
    WHERE meeting_attendance.user_id = ?";
$stmt = $conn->prepare($meeting_attendance_query);
$stmt->bind_param("i", $user_id);
$stmt->execute();
$meeting_attendance_result = $stmt->get_result();

// Fetch user's discussions
$discussions_query = "
    SELECT discussion_id, title, created_at
    FROM discussions
    WHERE user_id = ?
    ORDER BY created_at DESC";
$stmt = $conn->prepare($discussions_query);
$stmt->bind_param("i", $user_id);
$stmt->execute();
$discussions_result = $stmt->get_result();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>My Activity & Reports</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
    <style>
        body {
            background-color: #f8f9fa;
            font-family: Arial, sans-serif;
        }
        .container {
            margin-top: 30px;
        }
        .card {
            transition: transform 0.2s;
            box-shadow: 0px 4px 8px rgba(0, 0, 0, 0.1);
            margin-bottom: 20px;
        }
        .card:hover {
            transform: scale(1.02);
        }
        .status {
            font-weight: bold;
            padding: 5px 10px;
            border-radius: 5px;
        }
        .returned {
            background-color: #28a745;
            color: white;
        }
        .pending {
            background-color: #dc3545;
            color: white;
        }
    </style>
</head>
<body>

<div class="container">
    <h2 class="text-center mb-4">📊 My Activity & Reports</h2>

    <!-- Borrowed Books Report -->
    <div class="card p-3">
        <h3>📚 Borrowed Books</h3>
        <?php if ($borrowed_books_result->num_rows > 0) { ?>
            <div class="table-responsive">
                <table class="table table-bordered table-striped">
                    <thead>
                        <tr>
                            <th>Book Title</th>
                            <th>Author</th>
                            <th>Borrow Date</th>
                            <th>Return Date</th>
                            <th>Status</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php while ($book = $borrowed_books_result->fetch_assoc()) { ?>
                            <tr>
                                <td><?= htmlspecialchars($book['title']) ?></td>
                                <td><?= htmlspecialchars($book['author']) ?></td>
                                <td><?= $book['borrow_date'] ?></td>
                                <td><?= $book['return_date'] ?: 'Not Returned' ?></td>
                                <td>
                                    <span class="status <?= $book['return_date'] ? 'returned' : 'pending' ?>">
                                        <?= $book['return_date'] ? 'Returned' : 'Pending' ?>
                                    </span>
                                </td>
                            </tr>
                        <?php } ?>
                    </tbody>
                </table>
            </div>
        <?php } else { ?>
            <p>No borrowed books found.</p>
        <?php } ?>
    </div>

    <!-- Meeting Attendance Report -->
    <div class="card p-3">
        <h3>📅 Meeting Attendance</h3>
        <?php if ($meeting_attendance_result->num_rows > 0) { ?>
            <div class="table-responsive">
                <table class="table table-bordered table-striped">
                    <thead>
                        <tr>
                            <th>Meeting Title</th>
                            <th>Meeting Date</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php while ($meeting = $meeting_attendance_result->fetch_assoc()) { ?>
                            <tr>
                                <td><?= htmlspecialchars($meeting['title']) ?></td>
                                <td><?= $meeting['meeting_date'] ?></td>
                            </tr>
                        <?php } ?>
                    </tbody>
                </table>
            </div>
        <?php } else { ?>
            <p>No meeting attendance records found.</p>
        <?php } ?>
    </div>

    <!-- Discussions Report -->
    <div class="card p-3">
        <h3>💬 Discussions Started</h3>
        <?php if ($discussions_result->num_rows > 0) { ?>
            <div class="list-group">
                <?php while ($discussion = $discussions_result->fetch_assoc()) { ?>
                    <a href="discussion_details.php?id=<?= $discussion['discussion_id'] ?>" class="list-group-item list-group-item-action">
                        <strong><?= htmlspecialchars($discussion['title']) ?></strong> 
                        <span class="text-muted">(<?= $discussion['created_at'] ?>)</span>
                    </a>
                <?php } ?>
            </div>
        <?php } else { ?>
            <p>No discussions started.</p>
        <?php } ?>
    </div>

</div>
<a href="user_dashboard.php" class="back-link">
        <button class="back-button">⬅ Back to Dashboard</button>
    </a>
</body>
</html>
