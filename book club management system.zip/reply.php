<?php
// Include the database connection file
include('db_connect.php');
session_start();

// Check if the user is logged in
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit();
}

// Handle the form submission for new discussion posts
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['submit_post'])) {
    $user_id = $_SESSION['user_id'];
    $post_content = mysqli_real_escape_string($conn, $_POST['post_content']);
    $query = "INSERT INTO forum_posts (user_id, content, created_at) VALUES ('$user_id', '$post_content', NOW())";
    
    if (!mysqli_query($conn, $query)) {
        // Display any query error
        echo "Error: " . mysqli_error($conn);
    }
    header("Location: discussion_forum.php"); // Redirect to avoid resubmission on refresh
}

// Fetch the posts
$query = "SELECT fp.id, fp.content, fp.created_at, u.username FROM forum_posts fp JOIN users u ON fp.user_id = u.id ORDER BY fp.created_at DESC";
$result = mysqli_query($conn, $query);

// Check if the query was successful
if (!$result) {
    // Output SQL error if the query fails
    die("Query Failed: " . mysqli_error($conn));
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Discussion Forum</title>
    <link rel="stylesheet" href="style.css"> <!-- Include your styles -->
</head>
<body>

    <h1>Discussion Forum</h1>

    <!-- Form to post a new discussion -->
    <form action="discussion_forum.php" method="POST">
        <textarea name="post_content" rows="5" cols="50" placeholder="Share your thoughts..."></textarea>
        <br>
        <button type="submit" name="submit_post">Post</button>
    </form>

    <h2>Recent Discussions</h2>

    <?php
    // Check if the result has rows and display posts
    if (mysqli_num_rows($result) > 0) {
        while ($row = mysqli_fetch_assoc($result)) {
            echo "<div class='post'>";
            echo "<p><strong>" . htmlspecialchars($row['username']) . "</strong> <small>on " . $row['created_at'] . "</small></p>";
            echo "<p>" . nl2br(htmlspecialchars($row['content'])) . "</p>";

            // Reply Section
            echo "<a href='reply.php?post_id=" . $row['id'] . "'>Reply</a>";

            echo "</div>";
        }
    } else {
        echo "<p>No posts available. Be the first to start a discussion!</p>";
    }
    ?>

</body>
</html>
