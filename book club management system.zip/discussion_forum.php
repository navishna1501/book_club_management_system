<?php
// Include the database connection file
include('db_connect.php');
session_start();

// Check if the user is logged in
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit();
}

// Get the post ID from the URL
if (isset($_GET['post_id'])) {
    $post_id = $_GET['post_id'];
} else {
    die("Invalid post ID.");
}

// Handle the form submission for replies
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['submit_reply'])) {
    $user_id = $_SESSION['user_id'];
    $reply_content = mysqli_real_escape_string($conn, $_POST['reply_content']);
    
    $query = "INSERT INTO forum_replies (post_id, user_id, reply_content, created_at) VALUES ('$post_id', '$user_id', '$reply_content', NOW())";
    
    if (!mysqli_query($conn, $query)) {
        echo "Error: " . mysqli_error($conn);
    }
    
    header("Location: discussion_forum.php"); // Redirect back to the forum after posting a reply
}

// Fetch the original post details
$query = "SELECT * FROM forum_posts WHERE id = '$post_id'";
$result = mysqli_query($conn, $query);
if (!$result) {
    die("Query Failed: " . mysqli_error($conn));
}

$post = mysqli_fetch_assoc($result);

// Fetch replies to the post
$query_replies = "SELECT r.reply_content, r.created_at, u.username FROM forum_replies r JOIN users u ON r.user_id = u.id WHERE r.post_id = '$post_id' ORDER BY r.created_at ASC";
$result_replies = mysqli_query($conn, $query_replies);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Reply to Post</title>
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;500&display=swap" rel="stylesheet">
    <style>
        body {
            font-family: 'Roboto', sans-serif;
            background-color: #f9f9f9;
            margin: 0;
            padding: 0;
            color: #333;
        }
        header {
            background-color: #4CAF50;
            color: white;
            padding: 20px;
            text-align: center;
        }
        .container {
            width: 80%;
            margin: 0 auto;
        }
        .reply-form {
            background-color: #fff;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
            margin-bottom: 30px;
        }
        .reply-form textarea {
            width: 100%;
            padding: 10px;
            font-size: 16px;
            border: 1px solid #ddd;
            border-radius: 5px;
            resize: vertical;
            margin-bottom: 10px;
        }
        .reply-form button {
            background-color: #4CAF50;
            color: white;
            border: none;
            padding: 10px 20px;
            font-size: 16px;
            border-radius: 5px;
            cursor: pointer;
            transition: background-color 0.3s ease;
        }
        .reply-form button:hover {
            background-color: #45a049;
        }
        .replies {
            display: flex;
            flex-direction: column;
            gap: 20px;
        }
        .reply {
            background-color: #fff;
            padding: 15px;
            border-radius: 8px;
            box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
        }
        .reply-header {
            font-weight: bold;
            font-size: 18px;
        }
        .reply-content {
            margin-top: 10px;
            font-size: 16px;
            line-height: 1.5;
        }
    </style>
</head>
<body>
    <header>
        <h1>Reply to Post</h1>
    </header>

    <div class="container">
        <div class="post">
            <h2>Original Post</h2>
            <div class="post-header"><?php echo htmlspecialchars($post['username']) . " - " . $post['created_at']; ?></div>
            <div class="post-content"><?php echo nl2br(htmlspecialchars($post['content'])); ?></div>
        </div>

        <!-- Reply Form -->
        <div class="reply-form">
            <h2>Post a Reply</h2>
            <form action="reply.php?post_id=<?php echo $post_id; ?>" method="POST">
                <textarea name="reply_content" rows="5" placeholder="Share your reply..." required></textarea>
                <button type="submit" name="submit_reply">Post Reply</button>
            </form>
        </div>

        <!-- Display Replies -->
        <div class="replies">
            <h2>Replies</h2>
            <?php
            if (mysqli_num_rows($result_replies) > 0) {
                while ($reply = mysqli_fetch_assoc($result_replies)) {
                    echo "<div class='reply'>";
                    echo "<div class='reply-header'>" . htmlspecialchars($reply['username']) . " on " . $reply['created_at'] . "</div>";
                    echo "<div class='reply-content'>" . nl2br(htmlspecialchars($reply['reply_content'])) . "</div>";
                    echo "</div>";
                }
            } else {
                echo "<p>No replies yet. Be the first to reply!</p>";
            }
            ?>
        </div>
    </div>
</body>
</html>
