<?php
session_start();
$conn = new mysqli("localhost", "root", "", "book_club_system");

if (!isset($_SESSION["user_id"]) || $_SESSION["role"] != "admin") {
    header("Location: login.php");
    exit();
}

// Fetch books
$books = $conn->query("SELECT * FROM books");
if (!$books) {
    die("Database query failed: " . $conn->error);
}

// Fetch meetings
$meetings = $conn->query("SELECT * FROM meetings ORDER BY meeting_date ASC");
if (!$meetings) {
    die("Database query failed: " . $conn->error);
}

// Fetch users
$users = $conn->query("SELECT * FROM users");
if (!$users) {
    die("Database query failed: " . $conn->error);
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Admin Dashboard</title>
    <link rel="stylesheet" href="styles.css">
    <style>
    body {
        background: url('images/admin1.jpg') no-repeat center center fixed;
        background-size: cover;
        font-family: Arial, sans-serif;
        margin: 0;
        padding: 0;
    }

    .dashboard-container {
        background-color: rgba(155, 12, 12, 0.9); /* Slight white overlay for readability */
        padding: 30px;
        margin: 50px auto;
        width: 90%;
        max-width: 1000px;
        border-radius: 12px;
        box-shadow: 0 0 15px rgba(0, 0, 0, 0.3);
    }

    h1 {
        color: #333;
        text-align: center;
    }



        .dashboard-nav {
            display: flex;
            justify-content: space-around;
            padding: 15px;
            background: #007BFF;
            color: white;
            font-size: 16px;
        }
        .dashboard-nav a {
            color: white;
            text-decoration: none;
            padding: 10px 15px;
            border-radius: 5px;
            transition: background 0.3s;
        }
        .dashboard-nav a:hover {
            background: #0056b3;
        }
        .section {
            margin-top: 20px;
            padding: 15px;
            background: #fff;
            border-radius: 5px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }
        button {
            background: #007BFF;
            color: white;
            border: none;
            padding: 10px;
            border-radius: 5px;
            cursor: pointer;
        }
        button:hover {
            background: #0056b3;
        }
        .logout {
            background: red;
            padding: 10px;
            border-radius: 5px;
        }
    </style>
</head>
<body>

<div class="dashboard-nav">
    <a href="manage_books.php">📚 Manage Books</a>
    <a href="manage_meetings.php">📅 Manage Meetings</a>
    <a href="manage_users.php">👥 Manage Users</a>
    <a href="admin_discussion.php">💬 Manage Discussions</a>
    <a href="user_activity_reports.php">📊 User Activity & Reports</a>
    <a href="logout.php" class="logout">🚪 Logout</a>
</div>

<div class="container">
    <h2 style="color:rgb(53, 220, 75);">📊 Admin Dashboard</h2>

    <div class="section">
        <h3>📚 Books Management</h3>
        <ul>
            <?php while ($book = $books->fetch_assoc()) { ?>
                <li><?= htmlspecialchars($book['title']) ?> by <?= htmlspecialchars($book['author']) ?> 
                    (<?= $book['available_copies'] ?> copies available)</li>
            <?php } ?>
        </ul>
        <a href="manage_books.php"><button>➕ Manage Books</button></a>
    </div>

    <div class="section">
        <h3>📅 Upcoming Meetings</h3>
        <ul>
            <?php while ($meeting = $meetings->fetch_assoc()) { ?>
                <li><?= htmlspecialchars($meeting['title']) ?> on <?= $meeting['meeting_date'] ?></li>
            <?php } ?>
        </ul>
        <a href="manage_meetings.php"><button>📌 Schedule Meeting</button></a>
    </div>

    <div class="section">
        <h3>👥 User Management</h3>
        <ul>
            <?php while ($user = $users->fetch_assoc()) { ?>
                <li><?= htmlspecialchars($user['name']) ?> (<?= htmlspecialchars($user['email']) ?>) 
                    - Role: <?= ucfirst($user['role']) ?></li>
            <?php } ?>
        </ul>
        <a href="manage_users.php"><button>⚙️ Manage Users</button></a>
    </div>

    <div class="section">
        <h3>💬 Discussion Management</h3>
        <p>View and manage discussions posted by users.</p>
        <a href="admin_discussion.php"><button>🛠️ Manage Discussions</button></a>
    </div>

    <div class="section">
        <h3>📊 Reports & Analytics</h3>
        <a href="user_activity_reports.php"><button>📊 User Activity & Reports</button></a>
    </div>
</div>

</body>
</html>
