<?php
session_start();
$conn = new mysqli("localhost", "root", "", "book_club_system");

if (!isset($_SESSION["user_id"])) {
    header("Location: login.php");
    exit();
}

$user_id = $_SESSION["user_id"];
$discussion_id = intval($_GET['discussion_id'] ?? 0);

// Fetch discussion for user
$stmt = $conn->prepare("SELECT * FROM discussions WHERE discussion_id = ? AND user_id = ?");
$stmt->bind_param("ii", $discussion_id, $user_id);
$stmt->execute();
$result = $stmt->get_result();
$discussion = $result->fetch_assoc();

if (!$discussion) {
    echo "<script>alert('Discussion not found or unauthorized!'); window.location.href='user_discussion.php';</script>";
    exit();
}

// Update logic
if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $title = trim($_POST["title"]);
    $message = trim($_POST["message"]);

    if (!empty($title) && !empty($message)) {
        $update_stmt = $conn->prepare("UPDATE discussions SET title = ?, message = ? WHERE discussion_id = ? AND user_id = ?");
        $update_stmt->bind_param("ssii", $title, $message, $discussion_id, $user_id);

        if ($update_stmt->execute()) {
            header("Location: user_discussion.php");
            exit();
        } else {
            echo "<script>alert('❌ Update failed.');</script>";
        }
    } else {
        echo "<script>alert('⚠️ Title and message cannot be empty.');</script>";
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Edit Discussion</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
</head>
<body class="container mt-5">
    <h3>✏️ Edit Discussion</h3>
    <form method="POST">
        <div class="mb-3">
            <label class="form-label">Title</label>
            <input type="text" name="title" class="form-control" value="<?= htmlspecialchars($discussion['title']) ?>" required>
        </div>
        <div class="mb-3">
            <label class="form-label">Message</label>
            <textarea name="message" class="form-control" rows="5" required><?= htmlspecialchars($discussion['message']) ?></textarea>
        </div>
        <button type="submit" class="btn btn-success">💾 Save</button>
        <a href="user_discussion.php" class="btn btn-secondary">⬅ Cancel</a>
    </form>
</body>
</html>
