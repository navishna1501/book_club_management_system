<?php
session_start();
$conn = new mysqli("localhost", "root", "", "book_club_system");

// Check if user is logged in
if (!isset($_SESSION["user_id"])) {
    header("Location: login.php");
    exit();
}

// Fetch upcoming meetings
$meetings = $conn->query("SELECT * FROM meetings ORDER BY meeting_date ASC");
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Upcoming Meetings</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
    <style>
        body {
            background-color: #f8f9fa;
            font-family: Arial, sans-serif;
        }
        .container {
            margin-top: 30px;
        }
        .card {
            margin-bottom: 15px;
            padding: 15px;
            box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.1);
        }
        .btn-rsvp {
            float: right;
        }
    </style>
</head>
<body>

<div class="container">
    <h2 class="text-center mb-4">📅 Upcoming Meetings</h2>

    <?php if ($meetings->num_rows > 0) { ?>
        <ul class="list-group">
            <?php while ($meeting = $meetings->fetch_assoc()) { ?>
                <li class="list-group-item">
                    <strong><?= htmlspecialchars($meeting["title"]) ?></strong> 
                    on <?= $meeting["meeting_date"] ?>
                    <a href="rsvp.php?meeting_id=<?= $meeting["meeting_id"] ?>" class="btn btn-primary btn-sm btn-rsvp">RSVP</a>
                </li>
            <?php } ?>
        </ul>
    <?php } else { ?>
        <p class="text-center text-muted">No upcoming meetings.</p>
    <?php } ?>

    <!-- Back to Dashboard Button -->
    <div class="text-center mt-4">
        <a href="user_dashboard.php" class="btn btn-secondary">⬅️ Back to Dashboard</a>
    </div>
</div>

</body>
</html>
