<?php
session_start();
$conn = new mysqli("localhost", "root", "", "book_club_system");

if (!isset($_SESSION["user_id"])) {
    header("Location: login.php");
    exit();
}

$user_id = $_SESSION["user_id"];
$discussion_id = intval($_GET['discussion_id'] ?? 0);

// Only delete if discussion belongs to the user
$stmt = $conn->prepare("DELETE FROM discussions WHERE discussion_id = ? AND user_id = ?");
$stmt->bind_param("ii", $discussion_id, $user_id);
$stmt->execute();

if ($stmt->affected_rows > 0) {
    echo "<script>alert('🗑️ Discussion deleted.');</script>";
} else {
    echo "<script>alert('❌ You can only delete your own discussions.');</script>";
}

echo "<script>window.location.href='user_discussion.php';</script>";
exit();
?>
