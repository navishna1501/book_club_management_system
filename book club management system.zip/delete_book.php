<?php
session_start();
$conn = new mysqli("localhost", "root", "", "book_club_system");

// Redirect if not logged in or not an admin
if (!isset($_SESSION["user_id"]) || $_SESSION["role"] != "admin") {
    header("Location: login.php");
    exit();
}

// Fetch books
$books = $conn->query("SELECT book_id, title FROM books ORDER BY title ASC");

if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['delete_book_id'])) {
    // Handle book deletion
    $book_id = $_POST['delete_book_id'];
    if (is_numeric($book_id)) {
        $delete_stmt = $conn->prepare("DELETE FROM books WHERE book_id = ?");
        $delete_stmt->bind_param("i", $book_id);
        if ($delete_stmt->execute()) {
            echo "<p class='success'>Book deleted successfully!</p>";
        } else {
            echo "<p class='error'>Failed to delete the book.</p>";
        }
        $delete_stmt->close();
    } else {
        echo "<p class='error'>Invalid book ID!</p>";
    }
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Books | Book Club</title>
    <style>
        /* General Styles */
        * {
            box-sizing: border-box;
            margin: 0;
            padding: 0;
            font-family: Arial, sans-serif;
        }

        body {
            background: linear-gradient(135deg, #74ebd5, #ACB6E5);
            display: flex;
            flex-direction: column;
            align-items: center;
            min-height: 100vh;
            padding: 20px;
        }

        h2 {
            color: #333;
            margin-bottom: 20px;
            font-size: 24px;
        }

        /* Table Styles */
        table {
            width: 80%;
            max-width: 900px;
            border-collapse: collapse;
            margin: 20px 0;
            background-color: white;
            border-radius: 8px;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
        }

        table thead {
            background-color: #007BFF;
            color: white;
        }

        table th, table td {
            padding: 12px 15px;
            text-align: left;
        }

        table tbody tr:nth-child(even) {
            background-color: #f4f4f4;
        }

        table tbody tr:hover {
            background-color: #e0f7fa;
        }

        /* Button Styles */
        button {
            background: #007BFF;
            color: white;
            border: none;
            padding: 10px 20px;
            border-radius: 5px;
            cursor: pointer;
            transition: background-color 0.3s ease;
            font-size: 16px;
        }

        button:hover {
            background-color: #0056b3;
        }

        button:active {
            background-color: #004085;
        }

        /* Confirmation Button Styles (Delete) */
        button[type="submit"]:hover {
            background-color: #ff4d4d;
        }

        a {
            text-decoration: none;
            color: #007BFF;
            font-weight: bold;
            margin-top: 20px;
        }

        a:hover {
            text-decoration: underline;
        }

        /* Back Link */
        a.back {
            margin-top: 20px;
            display: inline-block;
            padding: 10px 20px;
            background-color: #28a745;
            color: white;
            border-radius: 5px;
            transition: background-color 0.3s ease;
        }

        a.back:hover {
            background-color: #218838;
        }

        /* Alert/Error Messages */
        p {
            color: #333;
            font-size: 16px;
            font-weight: bold;
        }

        p.success {
            color: green;
        }

        p.error {
            color: red;
        }

        /* Responsive Design */
        @media (max-width: 768px) {
            table {
                width: 100%;
            }

            button {
                width: 100%;
            }
        }
    </style>
</head>
<body>
    <h2>📚 Manage Books</h2>

    <table>
        <thead>
            <tr>
                <th>Title</th>
                <th>Action</th>
            </tr>
        </thead>
        <tbody>
            <?php while ($book = $books->fetch_assoc()) { ?>
                <tr>
                    <td><?= htmlspecialchars($book['title']); ?></td>
                    <td>
                        <form method="POST" style="display:inline;">
                            <button type="submit" name="delete_book_id" value="<?= $book['book_id']; ?>" onclick="return confirm('Are you sure you want to delete this book?');">Delete</button>
                        </form>
                    </td>
                </tr>
            <?php } ?>
        </tbody>
    </table>

    <a href="admin_dashboard.php" class="back">Back to Dashboard</a>
</body>
</html>
