<?php
session_start();
$conn = new mysqli("localhost", "root", "", "book_club_system");

// Check for database connection errors
if ($conn->connect_error) {
    die("Database Connection Failed: " . $conn->connect_error);
}

// Check if user is logged in
if (!isset($_SESSION["user_id"])) {
    header("Location: login.php");
    exit();
}

$user_id = $_SESSION["user_id"];

// Fetch user details securely
$user_query = "SELECT * FROM users WHERE user_id = ?";
$stmt = $conn->prepare($user_query);
$stmt->bind_param("i", $user_id);
$stmt->execute();
$user_result = $stmt->get_result();

if ($user_result && $user_result->num_rows > 0) {
    $user = $user_result->fetch_assoc();
} else {
    die("Error: User not found.");
}

// Fetch available books
$books_query = "SELECT * FROM books WHERE available_copies > 0";
$books_result = $conn->query($books_query);

// Fetch upcoming meetings
$meetings_query = "SELECT * FROM meetings ORDER BY meeting_date ASC";
$meetings_result = $conn->query($meetings_query);

// Fetch borrowed books
$borrowed_books_query = "SELECT books.title, books.author, borrowed_books.borrow_date, borrowed_books.return_date 
                         FROM borrowed_books 
                         JOIN books ON borrowed_books.book_id = books.book_id 
                         WHERE borrowed_books.user_id = ?";
$stmt = $conn->prepare($borrowed_books_query);
$stmt->bind_param("i", $user_id);
$stmt->execute();
$borrowed_books_result = $stmt->get_result();

// Fetch attended meetings
$meetings_attended_query = "SELECT meetings.title, meetings.meeting_date 
                            FROM meeting_attendance 
                            JOIN meetings ON meeting_attendance.meeting_id = meetings.meeting_id 
                            WHERE meeting_attendance.user_id = ?";
$stmt = $conn->prepare($meetings_attended_query);
$stmt->bind_param("i", $user_id);
$stmt->execute();
$meetings_attended_result = $stmt->get_result();

// Fetch discussion participation count
$discussion_query = "SELECT COUNT(*) AS discussion_count FROM discussions WHERE user_id = ?";
$stmt = $conn->prepare($discussion_query);
$stmt->bind_param("i", $user_id);
$stmt->execute();
$discussion_result = $stmt->get_result();
$discussion_count = $discussion_result->fetch_assoc()['discussion_count'] ?? 0;
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User Dashboard</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
    <style>
        body {
            background-color: #f8f9fa;
            font-family: Arial, sans-serif;
        }
        .container {
            margin-top: 30px;
        }
        .card {
            transition: transform 0.2s;
        }
        .card:hover {
            transform: scale(1.05);
        }
        .btn-primary {
            background-color: #007BFF;
            border: none;
        }
        .btn-primary:hover {
            background-color: #0056b3;
        }
        .banner-img {
            max-height: 300px;
            object-fit: cover;
        }
        .overlay-text {
            z-index: 2;
        }
    </style>
</head>
<body>

<!-- Banner with Text Overlay -->
<div class="position-relative">
    <img src="https://orion-uploads.openroadmedia.com/lg_3f63f86a2a19-onlinebookclub.jpg" class="img-fluid w-100 banner-img" alt="Dashboard Banner">
    <div class="position-absolute top-50 start-50 translate-middle text-center text-white bg-dark bg-opacity-50 p-3 rounded overlay-text">
        <h1 class="display-5 fw-bold">📚 Welcome to Your Book Club Dashboard</h1>
        <p class="lead">Explore books, join meetings, and track your reading journey!</p>
    </div>
</div>

<div class="container">
    <h2 class="text-center mb-4">Welcome, <?= htmlspecialchars($user['name']) ?>! 🎉</h2>

    <!-- Navigation Menu -->
    <div class="card p-3 shadow-sm">
        <h4 class="text-center">📌 Dashboard Menu</h4>
        <div class="text-center">
            <a href="browse_books.php" class="btn btn-primary m-2">📚 Browse Books</a>
            <a href="meetings.php" class="btn btn-primary m-2">📅 Upcoming Meetings</a>
            <a href="user_discussion.php" class="btn btn-primary m-2">💬 Discussion Forum</a>
            <a href="notifications.php" class="btn btn-primary m-2">🔔 Notifications</a>
            <a href="my_activity.php" class="btn btn-primary m-2">📊 My Activity & Reports</a>
            <a href="profile.php" class="btn btn-primary m-2">⚙️ Settings & Profile</a>
            <a href="logout.php" class="btn btn-danger m-2">🚪 Logout</a>
        </div>
    </div>

    <!-- Available Books Section -->
    <h3 class="mt-4">📚 Available Books</h3>
    <div class="row">
        <?php while ($book = $books_result->fetch_assoc()) { ?>
            <div class="col-md-4">
                <div class="card p-3 shadow-sm mt-3">
                    <h5><?= htmlspecialchars($book['title']) ?></h5>
                    <p><strong>Author:</strong> <?= htmlspecialchars($book['author']) ?></p>
                    <p><strong>Available:</strong> <?= $book['available_copies'] ?> copies</p>
                    <a href="borrow_book.php?book_id=<?= $book['book_id'] ?>" class="btn btn-success">📖 Borrow</a>
                </div>
            </div>
        <?php } ?>
    </div>

    <!-- Upcoming Meetings Section -->
    <h3 class="mt-4">📅 Upcoming Meetings</h3>
    <div class="row">
        <?php while ($meeting = $meetings_result->fetch_assoc()) { ?>
            <div class="col-md-4">
                <div class="card p-3 shadow-sm mt-3">
                    <h5><?= htmlspecialchars($meeting['title']) ?></h5>
                    <p><?= htmlspecialchars($meeting['description']) ?></p>
                    <p><strong>📅 Date:</strong> <?= $meeting['meeting_date'] ?></p>
                    <a href="rsvp.php?meeting_id=<?= $meeting['meeting_id'] ?>" class="btn btn-warning">✅ RSVP</a>
                </div>
            </div>
        <?php } ?>
    </div>

    <!-- My Activity & Reports -->
    <h3 class="mt-4">📊 My Activity & Reports</h3>
    <div class="card p-3 shadow-sm mt-3">
        <h5>📘 Borrowed Books</h5>
        <ul>
            <?php while ($borrowed = $borrowed_books_result->fetch_assoc()) { ?>
                <li><strong><?= htmlspecialchars($borrowed['title']) ?></strong> by <?= htmlspecialchars($borrowed['author']) ?>
                    (Borrowed on <?= $borrowed['borrow_date'] ?>, Return by <?= $borrowed['return_date'] ?>)</li>
            <?php } ?>
        </ul>
        
        <h5>📅 Meeting Attendance</h5>
        <ul>
            <?php while ($attended = $meetings_attended_result->fetch_assoc()) { ?>
                <li>Attended <strong><?= htmlspecialchars($attended['title']) ?></strong> on <?= $attended['meeting_date'] ?></li>
            <?php } ?>
        </ul>

        <h5>💬 Discussion Participation</h5>
        <p>You have started <strong><?= $discussion_count ?></strong> discussions.</p>
    </div>
</div>

</body>
</html>
