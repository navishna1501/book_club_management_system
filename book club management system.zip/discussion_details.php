<?php
session_start();
$conn = new mysqli("localhost", "root", "", "book_club_system");

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$is_user = isset($_SESSION["user_id"]);
$is_admin = isset($_SESSION["admin_id"]);

if (!$is_user && !$is_admin) {
    header("Location: login.php");
    exit();
}

$discussion_id = $_GET['id'] ?? null;
if (!is_numeric($discussion_id)) {
    die("Invalid discussion ID.");
}

// Fetch discussion
$stmt = $conn->prepare("SELECT d.*, u.name FROM discussions d JOIN users u ON d.user_id = u.user_id WHERE d.discussion_id = ?");
$stmt->bind_param("i", $discussion_id);
$stmt->execute();
$discussion_result = $stmt->get_result();
if ($discussion_result->num_rows === 0) die("Discussion not found.");
$discussion = $discussion_result->fetch_assoc();

// Fetch user replies
$stmt = $conn->prepare("SELECT r.*, u.name FROM replies r JOIN users u ON r.user_id = u.user_id WHERE r.discussion_id = ? ORDER BY r.created_at ASC");
$stmt->bind_param("i", $discussion_id);
$stmt->execute();
$user_replies = $stmt->get_result();

// Fetch admin replies
$stmt = $conn->prepare("SELECT ar.*, a.name FROM admin_replies ar JOIN admins a ON ar.admin_id = a.admin_id WHERE ar.discussion_id = ? ORDER BY ar.replied_at ASC");
$stmt->bind_param("i", $discussion_id);
$stmt->execute();
$admin_replies = $stmt->get_result();

// Handle new user reply
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['reply_message']) && $is_user) {
    $msg = trim($_POST['reply_message']);
    if (!empty($msg)) {
        $stmt = $conn->prepare("INSERT INTO replies (discussion_id, user_id, message, created_at) VALUES (?, ?, ?, NOW())");
        $stmt->bind_param("iis", $discussion_id, $_SESSION["user_id"], $msg);
        $stmt->execute();
        header("Location: discussion_details.php?id=$discussion_id");
        exit();
    }
}

// Handle new admin reply
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['admin_reply']) && $is_admin) {
    $msg = trim($_POST['admin_reply']);
    if (!empty($msg)) {
        $stmt = $conn->prepare("INSERT INTO admin_replies (discussion_id, admin_id, reply, replied_at) VALUES (?, ?, ?, NOW())");
        $stmt->bind_param("iis", $discussion_id, $_SESSION["admin_id"], $msg);
        $stmt->execute();
        header("Location: discussion_details.php?id=$discussion_id");
        exit();
    }
}

// Handle edit/delete admin replies
if ($is_admin && isset($_POST['action']) && isset($_POST['reply_id'])) {
    $reply_id = $_POST['reply_id'];

    if ($_POST['action'] === 'delete') {
        $stmt = $conn->prepare("DELETE FROM admin_replies WHERE reply_id = ? AND admin_id = ?");
        $stmt->bind_param("ii", $reply_id, $_SESSION["admin_id"]);
        $stmt->execute();
        header("Location: discussion_details.php?id=$discussion_id");
        exit();
    }

    if ($_POST['action'] === 'edit' && isset($_POST['edited_reply'])) {
        $edited_reply = trim($_POST['edited_reply']);
        $stmt = $conn->prepare("UPDATE admin_replies SET reply = ? WHERE reply_id = ? AND admin_id = ?");
        $stmt->bind_param("sii", $edited_reply, $reply_id, $_SESSION["admin_id"]);
        $stmt->execute();
        header("Location: discussion_details.php?id=$discussion_id");
        exit();
    }
}

// ✅ Handle delete for user replies
if ($is_user && isset($_POST['delete_user_reply']) && isset($_POST['user_reply_id'])) {
    $reply_id = intval($_POST['user_reply_id']);
    $stmt = $conn->prepare("DELETE FROM replies WHERE reply_id = ? AND user_id = ?");
    $stmt->bind_param("ii", $reply_id, $_SESSION["user_id"]);
    $stmt->execute();
    header("Location: discussion_details.php?id=$discussion_id");
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Discussion Details</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
    <style>
        body { background-color: #f8f9fa; }
        .container { margin-top: 30px; }
        .card:hover { transform: scale(1.01); transition: 0.2s; }
    </style>
</head>
<body>
<div class="container">
    <h2 class="text-center mb-4">📢 <?= htmlspecialchars($discussion['title']) ?></h2>
    <div class="card p-3 shadow-sm">
        <h5>By: <?= htmlspecialchars($discussion['name']) ?> | <?= htmlspecialchars($discussion['created_at']) ?></h5>
        <p><?= nl2br(htmlspecialchars($discussion['message'])) ?></p>
    </div>

    <!-- User Replies -->
    <h4 class="mt-4">💬 User Replies</h4>
    <?php while ($reply = $user_replies->fetch_assoc()) { ?>
        <div class="card p-3 mt-2">
            <p><?= nl2br(htmlspecialchars($reply['message'])) ?></p>
            <small><strong><?= htmlspecialchars($reply['name']) ?></strong> | <?= $reply['created_at'] ?></small>
            <?php if ($is_user && $_SESSION["user_id"] == $reply["user_id"]) { ?>
                <form method="POST" class="mt-2" onsubmit="return confirm('Delete this reply?');">
                    <input type="hidden" name="user_reply_id" value="<?= $reply['reply_id'] ?>">
                    <button type="submit" name="delete_user_reply" class="btn btn-danger btn-sm">🗑️ Delete</button>
                </form>
            <?php } ?>
        </div>
    <?php } ?>

    <!-- Admin Replies -->
    <h4 class="mt-4">🛡️ Admin Replies</h4>
    <?php while ($reply = $admin_replies->fetch_assoc()) { ?>
        <div class="card p-3 mt-2 bg-light">
            <p><?= nl2br(htmlspecialchars($reply['reply'])) ?></p>
            <small><strong>Admin: <?= htmlspecialchars($reply['name']) ?></strong> | <?= $reply['replied_at'] ?></small>
            <?php if ($is_admin && $_SESSION["admin_id"] == $reply["admin_id"]) { ?>
                <form method="POST" class="mt-2 d-flex gap-2">
                    <input type="hidden" name="reply_id" value="<?= $reply['reply_id'] ?>">
                    <input type="text" name="edited_reply" value="<?= htmlspecialchars($reply['reply']) ?>" class="form-control" required>
                    <button name="action" value="edit" class="btn btn-warning btn-sm">✏️ Edit</button>
                    <button name="action" value="delete" class="btn btn-danger btn-sm" onclick="return confirm('Delete this reply?')">🗑️ Delete</button>
                </form>
            <?php } ?>
        </div>
    <?php } ?>

    <!-- Reply Form -->
    <div class="card p-3 shadow-sm mt-4">
        <h5 class="text-center"><?= $is_admin ? 'Admin Reply' : 'Add Your Reply' ?></h5>
        <form method="POST">
            <div class="mb-3">
                <textarea name="<?= $is_admin ? 'admin_reply' : 'reply_message' ?>" class="form-control" rows="4" required></textarea>
            </div>
            <button type="submit" class="btn btn-primary w-100">➡️ Post Reply</button>
        </form>
    </div>

    <div class="text-center mt-4">
        <a href="<?= $is_admin ? 'admin_dashboard.php' : 'user_dashboard.php' ?>" class="btn btn-secondary">🏠 Back to Dashboard</a>
    </div>
</div>
</body>
</html>
