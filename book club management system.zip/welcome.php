<?php
session_start(); // Start the session to check if the user is already logged in
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Welcome to the Book Club</title>
    <link rel="stylesheet" href="styles.css">
    <style>
        body {
            font-family: Arial, sans-serif;
            background: url('images/book.jpeg') no-repeat center center fixed;
            background-size: cover;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
            color: white;
        }

        /* Animation keyframes */
        @keyframes fadeIn {
            from {
                opacity: 0;
                transform: translateY(20px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        @keyframes slideDown {
            from {
                opacity: 0;
                transform: translateY(-50px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        .container {
            background: rgba(0, 0, 0, 0.6);
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.1);
            width: 80%;
            max-width: 900px;
            text-align: center;

            /* Animate container on load */
            animation: fadeIn 1.5s ease-out;
        }

        h1 {
            font-size: 36px;
            color: #fff;
            animation: slideDown 1s ease-out;
        }

        h2 {
            font-size: 24px;
            margin-bottom: 20px;
            color: #fff;
            animation: slideDown 1.2s ease-out;
        }

        p {
            color: #f4f4f4;
            font-size: 18px;
            line-height: 1.6;
        }

        .btn {
            display: inline-block;
            padding: 12px 20px;
            margin: 10px;
            text-decoration: none;
            color: white;
            background-color: #007BFF;
            border-radius: 5px;
            transition: transform 0.2s ease-in-out, background-color 0.3s;
        }

        .btn:hover {
            background-color: #0056b3;
            transform: scale(1.05);
        }

        .about-section {
            margin-top: 30px;
        }
    </style>
</head>
<body>

<div class="container">
    <h1>Welcome to the Book Club!</h1>
    <h2>Join us today to explore and discuss books with others!</h2>

    <?php if (isset($_SESSION['user_id'])): ?>
        <p>Welcome back, <?php echo $_SESSION['name']; ?>!</p>

        <?php 
        // Check if the logged-in user is an admin or regular user
        if ($_SESSION['role'] == 'admin'): 
        ?>
            <a href="admin_dashboard.php" class="btn">Go to Admin Dashboard</a>
        <?php else: ?>
            <a href="user_dashboard.php" class="btn">Go to User Dashboard</a>
        <?php endif; ?>

        <a href="logout.php" class="btn">Logout</a>
    <?php else: ?>
        <a href="login.php" class="btn">Login</a>
        <a href="register.php" class="btn">Register</a>
    <?php endif; ?>

    <div class="about-section">
        <h2>About the Book Club</h2>
        <p>
            Welcome to the Book Club, a place where book lovers can come together to explore new titles,
            share thoughts, borrow books, and participate in engaging discussions.
            Join today and become a part of a vibrant community of readers!
        </p>
    </div>
</div>

</body>
</html>
