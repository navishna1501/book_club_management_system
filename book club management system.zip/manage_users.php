<?php
session_start();
$conn = new mysqli("localhost", "root", "", "book_club_system");

if (!isset($_SESSION["user_id"]) || $_SESSION["role"] != "admin") {
    header("Location: login.php");
    exit();
}

// Fetch users from the database
$users = $conn->query("SELECT * FROM users ORDER BY role DESC");

// Handle role update
if (isset($_POST["update_role"])) {
    $user_id = $_POST["user_id"];
    $new_role = $_POST["role"];
    $conn->query("UPDATE users SET role='$new_role' WHERE user_id=$user_id");
    header("Location: manage_users.php");
}

// Handle user deletion
if (isset($_POST["delete_user"])) {
    $user_id = $_POST["user_id"];
    $conn->query("DELETE FROM users WHERE user_id=$user_id");
    header("Location: manage_users.php");
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Users</title>
    <link rel="stylesheet" href="styles.css">
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            text-align: center;
            padding: 20px;
        }
        .container {
            max-width: 800px;
            margin: auto;
            background: white;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.1);
        }
        h2 {
            color: #333;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }
        th, td {
            padding: 10px;
            border: 1px solid #ccc;
            text-align: center;
        }
        th {
            background: #007BFF;
            color: white;
        }
        .btn {
            padding: 8px 15px;
            margin: 5px;
            border: none;
            border-radius: 5px;
            color: white;
            cursor: pointer;
        }
        .edit-btn {
            background-color: #28a745;
        }
        .delete-btn {
            background-color: #dc3545;
        }
        .back-btn {
            display: block;
            text-align: center;
            padding: 10px;
            background: #007BFF;
            color: white;
            text-decoration: none;
            border-radius: 5px;
            margin-top: 20px;
        }
        .back-btn:hover {
            background: #0056b3;
        }
    </style>
</head>
<body>

<div class="container">
    <h2>👥 Manage Users</h2>

    <table>
        <tr>
            <th>Name</th>
            <th>Email</th>
            <th>Role</th>
            <th>Action</th>
        </tr>

        <?php while ($user = $users->fetch_assoc()) { ?>
        <tr>
            <td><?= $user['name'] ?></td>
            <td><?= $user['email'] ?></td>
            <td>
                <form method="POST">
                    <input type="hidden" name="user_id" value="<?= $user['user_id'] ?>">
                    <select name="role">
                        <option value="admin" <?= $user['role'] == "admin" ? "selected" : "" ?>>Admin</option>
                        <option value="member" <?= $user['role'] == "member" ? "selected" : "" ?>>Member</option>
                    </select>
                    <button type="submit" name="update_role" class="btn edit-btn">Update</button>
                </form>
            </td>
            <td>
                <?php if ($user['role'] != "admin") { ?>
                <form method="POST">
                    <input type="hidden" name="user_id" value="<?= $user['user_id'] ?>">
                    <button type="submit" name="delete_user" class="btn delete-btn" onclick="return confirm('Are you sure?')">Delete</button>
                </form>
                <?php } ?>
            </td>
        </tr>
        <?php } ?>

    </table>

    <a href="admin_dashboard.php" class="back-btn">⬅ Back to Dashboard</a>
</div>

</body>
</html>
